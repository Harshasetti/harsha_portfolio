<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = $_POST['amount'];
    $email = $_POST['email'];
    $paymentMethod = $_POST['paymentMethod'];

    // Simulate payment success/failure
    $isSuccessful = rand(0, 1); // 1 = Success, 0 = Failure

    // Email content
    $subject = $isSuccessful ? "Payment Successful" : "Payment Failed";
    $message = $isSuccessful ? 
        "Your payment of ₹$amount via $paymentMethod was successful!" : 
        "Your payment of ₹$amount via $paymentMethod has failed. Please try again.";
    
    $headers = "From: noreply@yourwebsite.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Send Email
    if (mail($email, $subject, $message, $headers)) {
        echo json_encode(["status" => $isSuccessful ? "success" : "failed", "message" => "Payment processed. Check your email."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Email sending failed."]);
    }
}
?>
