document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("paymentForm").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form submission

        let amount = document.getElementById("amount").value;
        let email = document.getElementById("email").value;
        let paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value;

        if (!amount || !email || !paymentMethod) {
            alert("Please fill all details.");
            return;
        }

        // Send data to PHP
        fetch("process_payment.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `amount=${amount}&email=${email}&paymentMethod=${paymentMethod}`
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => console.error("Error:", error));
    });
});
