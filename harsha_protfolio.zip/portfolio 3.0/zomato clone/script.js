// Navigate to restaurant page
function viewRestaurant(page) {
    window.location.href = page;
}

// Add to cart
function addToCart(item, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({ item, price });
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(item + " added to cart!");
}

// Load cart items
function loadCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartItems = document.getElementById("cart-items");
    let total = 0;

    cartItems.innerHTML = "";
    cart.forEach((product, index) => {
        total += product.price;
        cartItems.innerHTML += `<p>${product.item} - $${product.price} <button onclick="removeItem(${index})">Remove</button></p>`;
    });

    document.getElementById("total-price").innerText = total;
}

// Remove item from cart
function removeItem(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

// Clear cart
function clearCart() {
    localStorage.removeItem("cart");
    loadCart();
}

// Load cart on cart.html
if (window.location.pathname.includes("cart.html")) {
    loadCart();
}
