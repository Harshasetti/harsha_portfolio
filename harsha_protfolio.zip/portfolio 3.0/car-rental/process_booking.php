<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $date = $_POST['date'];
    $car = $_POST['car'];

    echo "<h2>Booking Successful!</h2>";
    echo "<p>Name: $name</p>";
    echo "<p>Email: $email</p>";
    echo "<p>Pick-up Date: $date</p>";
    echo "<p>Car Type: $car</p>";
}
?>
